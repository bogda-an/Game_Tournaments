import React from "react";

export default function LoadingSpinner({ fullScreen = false }) {
  return (
    <div className={`spinner-container ${fullScreen ? "full-screen" : ""}`}>
      <div className="loading-spinner"></div>
    </div>
  );
}