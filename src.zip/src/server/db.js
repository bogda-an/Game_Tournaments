const path = require("path");
const fs = require("fs");
const Database = require("better-sqlite3");

const dbPath = path.join(__dirname, "../database.db");

console.log(`Attempting to connect to database at: ${dbPath}`);

if (!fs.existsSync(dbPath)) {
  console.error("Error: Database file not found at", dbPath);
  process.exit(1); 
}

const db = new Database(dbPath, { verbose: console.log }); 
console.log(`Connected to database at: ${dbPath}`);

module.exports = db;
