const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");
const db = require("./db");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
const axios = require("axios");

const app = express();
app.use(cors());
app.use(bodyParser.json());

const SECRET_KEY = "your_secret_key";

// User registration
app.post("/api/register", async (req, res) => {
  const { email, password, role } = req.body;
  const hashedPassword = await bcrypt.hash(password, 10);

  try {
    const insert = db.prepare("INSERT INTO users (email, password, role) VALUES (?, ?, ?)");
    insert.run(email, hashedPassword, role);
    res.json({ success: true, message: "User registered successfully" });
  } catch (err) {
    res.status(500).json({ success: false, message: "Registration failed" });
  }
});

// User login
app.post("/api/login", async (req, res) => {
  const { email, password } = req.body;
  const user = db.prepare("SELECT * FROM users WHERE email = ?").get(email);

  if (!user || !(await bcrypt.compare(password, user.password))) {
    return res.status(401).json({ success: false, message: "Invalid credentials" });
  }

  const token = jwt.sign(
    { id: user.id, email: user.email, role: user.role },
    SECRET_KEY,
    { expiresIn: "1h" }
  );
  res.json({ success: true, user: { id: user.id, email: user.email, role: user.role }, token });
});

app.post("/api/sync-user", async (req, res) => {
  try {
    const { firebase_uid, email } = req.body;

    if (!firebase_uid || !email) {
      return res.status(400).json({ 
        success: false, 
        message: "Missing Firebase UID or email" 
      });
    }

    let user = db.prepare('SELECT * FROM users WHERE firebase_uid = ?')
                 .get(firebase_uid);

    if (!user) {
    const insert = db.prepare(`
      INSERT INTO users (firebase_uid, email, role) 
      VALUES (?, ?, 'user')
    `);
    insert.run(firebase_uid, email);
    user = db.prepare(`
      SELECT id, email, role, firebase_uid 
      FROM users 
      WHERE firebase_uid = ?
    `).get(firebase_uid);
  }

  res.json({ 
    user: {
      id: user.id,
      email: user.email,
      role: user.role,
      firebase_uid: user.firebase_uid
    }
  });
  
  } catch (error) {
    console.error("Sync error:", error);
    res.status(500).json({ 
      success: false,
      message: "User sync failed",
      error: error.message 
    });
  }
});

// Get all tournaments
app.get("/api/tournaments", (req, res) => {
  try {
    const tournaments = db.prepare("SELECT * FROM tournaments").all();
    res.json(tournaments);
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch tournaments" });
  }
});

// Create tournament with geocoding
app.post("/api/tournaments", async (req, res) => {
  try {
    const { game_id, title, date, location, available_spots } = req.body;
    
    const geocodeResponse = await axios.get(
      `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(location)}`
    );
    
    const firstResult = geocodeResponse.data[0];
    if (!firstResult) {
      return res.status(400).json({ error: "Could not find location coordinates" });
    }

    const latitude = parseFloat(firstResult.lat);
    const longitude = parseFloat(firstResult.lon);

    const insert = db.prepare(`
      INSERT INTO tournaments 
      (game_id, title, date, location, latitude, longitude, available_spots)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `);
    
    const result = insert.run(
      game_id,
      title,
      date,
      location,
      latitude,
      longitude,
      available_spots
    );

    res.json({
      id: result.lastInsertRowid,
      game_id,
      title,
      date,
      location,
      latitude,
      longitude,
      available_spots
    });
  } catch (error) {
    console.error("Tournament creation error:", error);
    res.status(500).json({ 
      error: "Failed to add tournament",
      details: error.message 
    });
  }
});

// Tournament registration
app.post("/api/register-tournament", (req, res) => {
  try {
    const { firebase_uid, tournament_id } = req.body;

    if (!firebase_uid || !tournament_id) {
      return res.status(400).json({ 
        success: false, 
        message: "Missing user or tournament ID" 
      });
    }

    const user = db.prepare(
      "SELECT id FROM users WHERE firebase_uid = ?"
    ).get(firebase_uid);
    
    if (!user) {
      return res.status(404).json({ 
        success: false, 
        message: "User not found" 
      });
    }

    const tournament = db.prepare(
      "SELECT * FROM tournaments WHERE id = ?"
    ).get(tournament_id);
    
    if (!tournament) {
      return res.status(404).json({ 
        success: false, 
        message: "Tournament not found" 
      });
    }

    if (tournament.available_spots <= 0) {
      return res.status(400).json({ 
        success: false, 
        message: "No spots available" 
      });
    }

    const existingRegistration = db.prepare(`
      SELECT * FROM registrations 
      WHERE user_id = ? AND tournament_id = ?
    `).get(user.id, tournament_id);
    
    if (existingRegistration) {
      return res.status(400).json({ 
        success: false, 
        message: "User already registered" 
      });
    }

    db.transaction(() => {
      db.prepare(`
        INSERT INTO registrations (user_id, tournament_id) 
        VALUES (?, ?)
      `).run(user.id, tournament_id);

      db.prepare(`
        UPDATE tournaments 
        SET available_spots = available_spots - 1 
        WHERE id = ?
      `).run(tournament_id);
    })();

    const updatedTournament = db.prepare(`
      SELECT available_spots FROM tournaments WHERE id = ?
    `).get(tournament_id);

    res.json({
      success: true,
      message: "Successfully registered",
      remaining_spots: updatedTournament.available_spots
    });
  } catch (error) {
    console.error("Registration error:", error.message);
    res.status(500).json({ 
      success: false, 
      message: "Internal server error during registration",
      error: error.message 
    });
  }
});
// Cancel registration
app.delete("/api/registrations", (req, res) => {
  try {
    const { firebase_uid, tournament_id } = req.body;

    if (!firebase_uid || !tournament_id) {
      return res.status(400).json({ 
        success: false, 
        message: "Missing required fields" 
      });
    }

    const user = db.prepare(
      "SELECT id FROM users WHERE firebase_uid = ?"
    ).get(firebase_uid);

    if (!user) {
      return res.status(404).json({ 
        success: false, 
        message: "User not found" 
      });
    }

    const tournamentId = parseInt(tournament_id, 10);

    db.transaction(() => {
      const deleteStmt = db.prepare(`
        DELETE FROM registrations 
        WHERE user_id = ? AND tournament_id = ?
      `);
      deleteStmt.run(user.id, tournamentId);

      const updateStmt = db.prepare(`
        UPDATE tournaments 
        SET available_spots = available_spots + 1 
        WHERE id = ?
      `);
      updateStmt.run(tournamentId);
    })();

    res.json({ 
      success: true, 
      message: "Registration cancelled successfully" 
    });
  } catch (error) {
    console.error("Cancellation error:", error);
    res.status(500).json({ 
      success: false, 
      message: "Internal server error",
      error: error.message 
    });
  }
});

// Get user registrations
app.get('/api/user-registrations/:firebase_uid', async (req, res) => {
  try {
    const firebaseUid = req.params.firebase_uid;

    const user = db.prepare(
      'SELECT id FROM users WHERE firebase_uid = ?'
    ).get(firebaseUid);

    if (!user) return res.json([]);

    const registrations = db.prepare(`
      SELECT t.id, t.title, t.date, t.location, 
             datetime(r.registration_date) as registration_date 
      FROM registrations r
      JOIN tournaments t ON r.tournament_id = t.id
      WHERE r.user_id = ?
    `).all(user.id);

    res.json(registrations);
  } catch (error) {
    console.error("Registration fetch error:", error);
    res.status(500).json({ error: "Failed to fetch registrations" });
  }
});

// Update tournament
app.put('/api/tournaments/:id', (req, res) => {
  try {
    const { id } = req.params;
    const { title, date, location, available_spots } = req.body;
    
    const update = db.prepare(`
      UPDATE tournaments SET
      title = ?,
      date = ?,
      location = ?,
      available_spots = ?
      WHERE id = ?
    `);
    
    update.run(title, date, location, available_spots, id);
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: 'Failed to update tournament' });
  }
});

// Delete tournament
app.delete('/api/tournaments/:id', (req, res) => {
  try {
    const { id } = req.params;
    
    db.transaction(() => {
      db.prepare('DELETE FROM registrations WHERE tournament_id = ?').run(id);
      db.prepare('DELETE FROM tournaments WHERE id = ?').run(id);
    })();
    
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: 'Failed to delete tournament' });
  }
});

app.listen(5000, () => console.log("Server running on port 5000"));